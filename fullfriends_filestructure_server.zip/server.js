var express = require('express');
var path = require('path');
var bp = require('body-parser');

// server.js doesn't diretly interact with mongoose so we don't need to require it
var app = express();

app.use(express.static(path.join(__dirname, './client')));
app.use(express.static(path.join(__dirname, './bower_component')));

app.use(bp.json());  // tells angular we'll be using angular

require('./server/config/routes.js')(app)

app.listen(8010, function(){
    console.log("listening to Full Friends on port 8010");
});
