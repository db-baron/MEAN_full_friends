// Bring friends controller into routes
var friends = require('../controllers/friends.js');

module.exports = function(app){

}
