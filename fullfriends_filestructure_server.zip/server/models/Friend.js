var mongoose = require('mongoose');
var Schema = mongoose.Schema;

// Create schema from our var Schema (i.e. mongoose.Schema)
var FriendSchema = new Schema({
    first_name: String,  // String class comes from our object constructor
    last_name: String
});

// Create the model "Friend"
mongoose.model("Friend", FriendSchema); //
