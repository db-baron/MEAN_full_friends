var mongoose = require('mongoose');
var Friend = mongoose.model('Friend');

// Export an immediately invoked function that returns as soon as it's invoked
module.exports = (function(){
    return {
        // Return calls to the database
        index: function(req, res){
            // Find everything
            Friend.find({}, function(err, results){
                if(err){
                    res.json(err);
                } else {
                    res.json(results);
                }
            })
        }
    }
})();
